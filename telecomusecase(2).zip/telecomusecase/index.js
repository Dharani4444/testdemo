const express = require("express");
const cors = require("cors");
const router = require("./route");

const swaggerUi = require("swagger-ui-express");
const swaggerJSDoc = require("swagger-jsdoc");
const swaggerOptions = require("./swagger.json");
const swaggerSpec = swaggerJSDoc(swaggerOptions);
const app = express();
app.use("/service/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));
app.use(express.json());
app.use(cors("*"));
app.use("/service", router);


const PORT = process.env.PORT || 3005;

// Middleware to parse JSON bodies
app.use(express.json());

// In-memory array to store items
let items = [
    { id: 1, name: "Item1", price: 10.99, quantity: 5 },
    { id: 2, name: "Item2", price: 15.99, quantity: 3 },
    { id: 3, name: "Item3", price: 7.49, quantity: 10 }
];

// Generate unique ID for items
const generateId = () => items.length ? Math.max(...items.map(item => item.id)) + 1 : 1;

// Create a new item (POST /items)
app.post('/items', (req, res) => {
    const { name, price, quantity } = req.body;
    if (!name || price === undefined || quantity === undefined) {
        return res.status(400).json({ error: "Name, price, and quantity are required" });
    }
    const newItem = { id: generateId(), name, price, quantity };
    items.push(newItem);
    res.status(201).json(newItem);
});

// Get all items (GET /items)
app.get('/items', (req, res) => {
    res.json(items);
});

// Get a specific item by ID (GET /items/:id)
app.get('/items/:id', (req, res) => {
    const item = items.find(i => i.id === parseInt(req.params.id));
    if (!item) {
        return res.status(404).json({ error: "Item not found" });
    }
    res.json(item);
});

// Update an item by ID (PUT /items/:id)
app.put('/items/:id', (req, res) => {
    const item = items.find(i => i.id === parseInt(req.params.id));
    if (!item) {
        return res.status(404).json({ error: "Item not found" });
    }
    const { name, price, quantity } = req.body;
    if (name !== undefined) item.name = name;
    if (price !== undefined) item.price = price;
    if (quantity !== undefined) item.quantity = quantity;
    res.json(item);
});

// Delete an item by ID (DELETE /items/:id)
app.delete('/items/:id', (req, res) => {
    const index = items.findIndex(i => i.id === parseInt(req.params.id));
    if (index === -1) {
        return res.status(404).json({ error: "Item not found" });
    }
    const deletedItem = items.splice(index, 1);
    res.json(deletedItem[0]);
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});


