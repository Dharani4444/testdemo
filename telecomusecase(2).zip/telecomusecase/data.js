var data = [
    {
      Customer_Name:"Peter",
      Address:"23 old baker street"
      //plan_name: "Land Line",
      //price: "200 monthly",
    },
    {
       Customer_Name:"dharani",
      Address:"23 old baker stree"
      //plan_name: "Broad_Band",
      //price: "400 monthly,1100 annually",
    },
    {
       Customer_Name:"sneha",
      Address:"23 old baker street"
      //plan_name: "5G Service",
      //price: "1000 Rs annual Subscription ",
    },
  ];
  module.exports = data;